pyexe.exe by David Manthey

License: Apache-2.0

Source: https://github.com/manthey/pyexe

Here is a stand-alone version of python that is a single Windows executable.

It consists of the most recent versions of Python (with builds for 2.7, 3.5, and 3.6 each in 32-bit and 64-bit versions), pywin32, psutil, six, pip, setuptools, and includes all packages that can be included without additional dlls, excepting tkinter.
